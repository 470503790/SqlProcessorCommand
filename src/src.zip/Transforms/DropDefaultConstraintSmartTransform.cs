using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class DropDefaultConstraintSmartTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+DROP\s+CONSTRAINT\s+\[(?<cname>[^\]]+)\]\s*$",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly Regex AutoDfRx = new Regex(@"^DF__[^_]+__([^_]+)__[0-9A-F]+$", RegexOptions.IgnoreCase);
        private static readonly Regex CustomDfRx = new Regex(@"^DF_[^_]+_(.+)$", RegexOptions.IgnoreCase);

        public bool CanHandle(string block)
        {
            var m = R.Match(block);
            if (!m.Success) return false;
            var cname = m.Groups["cname"].Value;
            return cname.StartsWith("DF", System.StringComparison.OrdinalIgnoreCase);
        }

        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            var cname = m.Groups["cname"].Value;

            string colPrefix = null;
            var ma = AutoDfRx.Match(cname);
            if (ma.Success) colPrefix = ma.Groups[1].Value;
            if (string.IsNullOrEmpty(colPrefix))
            {
                var mc = CustomDfRx.Match(cname);
                if (mc.Success) colPrefix = mc.Groups[1].Value;
            }

            var sql = $@"
DECLARE @__df sysname = NULL;
DECLARE @__col sysname = NULL;

SELECT @__df = dc.name
FROM sys.default_constraints dc
WHERE dc.parent_object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}')
  AND dc.name = N'{SqlId.Unquote(cname)}';

IF @__df IS NULL {(string.IsNullOrEmpty(colPrefix) ? "/* 无列前缀可用 */" : "" )}
BEGIN
    SELECT TOP (1) @__df = dc.name, @__col = c.name
    FROM sys.default_constraints dc
    JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}')
      {(string.IsNullOrEmpty(colPrefix) ? "" : "AND c.name LIKE N'" + colPrefix.Replace("'", "''") + "%'")}
    ORDER BY c.column_id;
END

IF @__df IS NOT NULL
    EXEC('ALTER TABLE {SqlId.Quote(schema)}.{SqlId.Quote(table)} DROP CONSTRAINT [' + @__df + ']');";

            return sql.Trim();
        }
    }
}
