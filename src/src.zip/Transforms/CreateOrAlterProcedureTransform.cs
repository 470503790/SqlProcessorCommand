using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class CreateOrAlterProcedureTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+(?:PROC|PROCEDURE)\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            return R.Replace(block, "CREATE OR ALTER PROCEDURE");
        }
    }
}
