using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    /// <summary>
    /// 将 CREATE FUNCTION 包装为：若不存在则 CREATE，否则 ALTER（兼容 SQL Server 2014）。
    /// 同时兼容标量函数(FN)、内联表值函数(IF)、多语句表值函数(TF)。
    /// </summary>
    internal class FunctionCreateAlterWrapper2014 : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+FUNCTION\s+(?:(?:\[(?<schema>[^\]]+)\]\.\[(?<name>[^\]]+)\])|(?:(?<schema2>\w+)\.(?<name2>\w+))|(?:\[(?<name3>[^\]]+)\])|(?<name4>\w+))(?<rest>[\s\S]*)$",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            var m = R.Match(block);
            string schema = m.Groups["schema"].Success ? m.Groups["schema"].Value :
                            (m.Groups["schema2"].Success ? m.Groups["schema2"].Value : "dbo");
            string name = m.Groups["name"].Success ? m.Groups["name"].Value :
                          (m.Groups["name2"].Success ? m.Groups["name2"].Value :
                          (m.Groups["name3"].Success ? m.Groups["name3"].Value : m.Groups["name4"].Value));
            string rest = m.Groups["rest"].Value;

            string header = $"[{schema}].[{name}]";

            string create = $"CREATE FUNCTION {header}{rest}";
            string alter  = $"ALTER FUNCTION {header}{rest}";

            return $@"
IF OBJECT_ID(N'{header}', N'FN') IS NULL 
   AND OBJECT_ID(N'{header}', N'IF') IS NULL 
   AND OBJECT_ID(N'{header}', N'TF') IS NULL
BEGIN
    {create}
END
ELSE
BEGIN
    {alter}
END".Trim();
        }
    }
}
