using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class AddColumnTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+ADD\s+\[(?<col>[^\]]+)\]\s+(?<rest>.+)$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            var col = m.Groups["col"].Value;
            return $@"
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}') AND name = N'{SqlId.Unquote(col)}')
BEGIN
    {block}
END".Trim();
        }
    }
}
