using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class CreateTableTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\b",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table  = m.Groups["table"].Value;
            return $@"
IF OBJECT_ID(N'[{schema}].[{table}]', N'U') IS NULL
BEGIN
    {block}
END".Trim();
        }
    }
}
