using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class DropIndexTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*DROP\s+INDEX\s+(?:\[(?<ix>[^\]]+)\]|(?<ix>\S+))\s+ON\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block)
        {
            var m = R.Match(block);
            var ix = SqlId.Unquote(m.Groups["ix"].Value);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            return $@"
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'{ix}' AND object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}'))
BEGIN
    DROP INDEX {SqlId.Quote(ix)} ON {SqlId.Quote(schema)}.{SqlId.Quote(table)}
END".Trim();
        }
    }
}
