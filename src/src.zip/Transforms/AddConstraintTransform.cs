using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class AddConstraintTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+ADD\s+CONSTRAINT\s+\[(?<cname>[^\]]+)\]\s+(?<ctype>PRIMARY\s+KEY|UNIQUE|DEFAULT|CHECK|FOREIGN\s+KEY)\b",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            var cname = m.Groups["cname"].Value;
            return $@"
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE name = N'{SqlId.Unquote(cname)}' AND parent_object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}'))
BEGIN
    {block}
END".Trim();
        }
    }
}
