using System.Text;
using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class AlterColumnTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+ALTER\s+COLUMN\s+\[(?<col>[^\]]+)\]\s+(?<type>.+)$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            var col = m.Groups["col"].Value;
            var typeClause = m.Groups["type"].Value;

            bool toNotNull = Regex.IsMatch(typeClause, @"\bNOT\s+NULL\b", RegexOptions.IgnoreCase);
            bool toNumeric = Regex.IsMatch(typeClause, @"\b(bit|tinyint|smallint|int|bigint|decimal|numeric|money|smallmoney|float|real)\b", RegexOptions.IgnoreCase);

            var sb = new StringBuilder();

            sb.AppendLine($@"IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}') AND name = N'{SqlId.Unquote(col)}')
BEGIN

    -- 1) 捕获并删除默认约束（保存定义，稍后恢复）
    DECLARE @__df  sysname;
    DECLARE @__def nvarchar(max);

    SELECT @__df = dc.name, @__def = dc.definition
    FROM sys.default_constraints dc
    JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}')
      AND c.name = N'{SqlId.Unquote(col)}';

    IF @__df IS NOT NULL EXEC('ALTER TABLE {SqlId.Quote(schema)}.{SqlId.Quote(table)} DROP CONSTRAINT [' + @__df + ']');

    -- 2) 捕获并删除依赖该列的非约束型索引（稍后重建）
    DECLARE @__idx TABLE(name sysname NOT NULL, create_sql nvarchar(max) NOT NULL);

    INSERT INTO @__idx(name, create_sql)
    SELECT i.name,
           N'CREATE ' +
           CASE WHEN i.is_unique = 1 THEN N'UNIQUE ' ELSE N'' END +
           CASE i.type WHEN 1 THEN N'CLUSTERED ' ELSE N'NONCLUSTERED ' END +
           N'INDEX ' + QUOTENAME(i.name) +
           N' ON {SqlId.Quote(schema)}.{SqlId.Quote(table)} (' +
           ISNULL(STUFF((
               SELECT N', ' + QUOTENAME(c.name) + CASE WHEN ic.is_descending_key = 1 THEN N' DESC' ELSE N' ASC' END
               FROM sys.index_columns ic
               JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
               WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
               ORDER BY ic.key_ordinal
               FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N''), N'') + N')' +
           CASE WHEN EXISTS(SELECT 1 FROM sys.index_columns ic WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 1)
                THEN N' INCLUDE (' +
                     ISNULL(STUFF((
                        SELECT N', ' + QUOTENAME(c2.name)
                        FROM sys.index_columns ic2
                        JOIN sys.columns c2 ON c2.object_id = ic2.object_id AND c2.column_id = ic2.column_id
                        WHERE ic2.object_id = i.object_id AND ic2.index_id = i.index_id AND ic2.is_included_column = 1
                        ORDER BY c2.column_id
                        FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N''), N'') + N')'
                ELSE N'' END +
           ISNULL(N' WHERE ' + i.filter_definition, N'')
    FROM sys.indexes i
    JOIN sys.index_columns ic0 ON ic0.object_id = i.object_id AND ic0.index_id = i.index_id
    WHERE i.object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}')
      AND ic0.column_id = COLUMNPROPERTY(OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}'), N'{SqlId.Unquote(col)}', 'ColumnId')
      AND i.is_primary_key = 0 AND i.is_unique_constraint = 0
      AND i.name IS NOT NULL;

    DECLARE @__n sysname;
    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT name FROM @__idx;
    OPEN cur;
    FETCH NEXT FROM cur INTO @__n;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @__sql_drop nvarchar(max);
        DECLARE @__q sysname = QUOTENAME(@__n);
        SET @__sql_drop = N'DROP INDEX ' + @__q + N' ON {SqlId.Quote(schema)}.{SqlId.Quote(table)}';
        EXEC sp_executesql @__sql_drop;

        FETCH NEXT FROM cur INTO @__n;
    END
    CLOSE cur; DEALLOCATE cur;");

            if (toNotNull && toNumeric)
            {
                sb.AppendLine($@"
    -- 3) 数值类型改 NOT NULL 前，先把 NULL 置 0
    UPDATE {SqlId.Quote(schema)}.{SqlId.Quote(table)} SET {SqlId.Quote(col)} = 0 WHERE {SqlId.Quote(col)} IS NULL;");
            }

            sb.AppendLine($@"
    -- 4) 真正 ALTER
    {block}

    -- 5) 恢复默认约束（若原存在）
    IF @__df IS NOT NULL AND @__def IS NOT NULL
    BEGIN
        DECLARE @__sql nvarchar(max) =
            N'ALTER TABLE {SqlId.Quote(schema)}.{SqlId.Quote(table)} ADD CONSTRAINT [' + @__df + N'] DEFAULT ' + @__def + N' FOR {SqlId.Quote(col)}';
        EXEC sp_executesql @__sql;
    END

    -- 6) 重建依赖该列的非约束型索引
    DECLARE @__create nvarchar(max);
    DECLARE cur2 CURSOR LOCAL FAST_FORWARD FOR SELECT create_sql FROM @__idx;
    OPEN cur2;
    FETCH NEXT FROM cur2 INTO @__create;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC sp_executesql @__create;
        FETCH NEXT FROM cur2 INTO @__create;
    END
    CLOSE cur2; DEALLOCATE cur2;
END");
            return sb.ToString().Trim();
        }
    }
}
