using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class DropColumnToEmptyTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"\bALTER\s+TABLE\b.+\bDROP\s+COLUMN\b", RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block) => string.Empty;
    }
}
