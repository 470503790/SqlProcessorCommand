using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class ExtendedPropertyTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*EXEC\s+(?:\[[^\]]+\]\.)?sp_(?<op>add|update)extendedproperty\s*(?<args>.+)$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);

        private static readonly Regex ArgNameRx  = new Regex(@"@name\s*=\s*N?'(?<v>[^']+)'",  RegexOptions.IgnoreCase);
        private static readonly Regex ArgValueRx = new Regex(@"@value\s*=\s*N?'(?<v>[^']*)'", RegexOptions.IgnoreCase);

        private static readonly Regex L0TypeRx = new Regex(@"@level0type\s*=\s*N?'(?<v>[^']+)'", RegexOptions.IgnoreCase);
        private static readonly Regex L0NameRx = new Regex(@"@level0name\s*=\s*N?'(?<v>[^']+)'", RegexOptions.IgnoreCase);
        private static readonly Regex L1TypeRx = new Regex(@"@level1type\s*=\s*N?'(?<v>[^']+)'", RegexOptions.IgnoreCase);
        private static readonly Regex L1NameRx = new Regex(@"@level1name\s*=\s*N?'(?<v>[^']+)'", RegexOptions.IgnoreCase);
        private static readonly Regex L2TypeRx = new Regex(@"@level2type\s*=\s*N?'(?<v>[^']+)'", RegexOptions.IgnoreCase);
        private static readonly Regex L2NameRx = new Regex(@"@level2name\s*=\s*N?'(?<v>[^']+)'", RegexOptions.IgnoreCase);

        private static readonly Regex StringTokenRx = new Regex(@"N?'((?:''|[^'])*)'", RegexOptions.IgnoreCase);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            var m = R.Match(block);
            var args = m.Groups["args"].Value;

            string name = ArgNameRx.Match(args).Groups["v"].Value;
            string value = ArgValueRx.Match(args).Groups["v"].Value;

            string l0t = L0TypeRx.Match(args).Groups["v"].Value;
            string l0n = L0NameRx.Match(args).Groups["v"].Value;
            string l1t = L1TypeRx.Match(args).Groups["v"].Value;
            string l1n = L1NameRx.Match(args).Groups["v"].Value;
            string l2t = L2TypeRx.Match(args).Groups["v"].Value;
            string l2n = L2NameRx.Match(args).Groups["v"].Value;

            if (string.IsNullOrEmpty(name) || (string.IsNullOrEmpty(value) && !HasExplicitNullValue(args)))
            {
                var tokens = new List<string>();
                foreach (Match sm in StringTokenRx.Matches(args))
                    tokens.Add(sm.Groups[1].Value.Replace("''", "'"));

                if (tokens.Count >= 2)
                {
                    if (string.IsNullOrEmpty(name))  name  = tokens[0];
                    if (string.IsNullOrEmpty(value)) value = tokens[1];
                }

                for (int i = 2; i + 1 < tokens.Count; i += 2)
                {
                    var t = tokens[i]; var n = tokens[i + 1];
                    if (string.IsNullOrEmpty(l0t) && (t.Equals("SCHEMA", StringComparison.OrdinalIgnoreCase) || t.Equals("USER", StringComparison.OrdinalIgnoreCase))) { l0t = t; l0n = n; continue; }
                    if (string.IsNullOrEmpty(l1t) && (t.Equals("TABLE", StringComparison.OrdinalIgnoreCase)  || t.Equals("VIEW",  StringComparison.OrdinalIgnoreCase))) { l1t = t; l1n = n; continue; }
                    if (string.IsNullOrEmpty(l2t) &&  t.Equals("COLUMN", StringComparison.OrdinalIgnoreCase)) { l2t = t; l2n = n; continue; }
                }
            }

            string schema = (!string.IsNullOrEmpty(l0t) && l0t.Equals("SCHEMA", StringComparison.OrdinalIgnoreCase)) ? l0n : "dbo";
            string table  = (!string.IsNullOrEmpty(l1t) && l1t.Equals("TABLE",  StringComparison.OrdinalIgnoreCase)) ? l1n
                          : (!string.IsNullOrEmpty(l0t) && l0t.Equals("TABLE",  StringComparison.OrdinalIgnoreCase) ? l0n : null);
            string column = (!string.IsNullOrEmpty(l2t) && l2t.Equals("COLUMN", StringComparison.OrdinalIgnoreCase)) ? l2n : null;

            if (string.IsNullOrEmpty(name))
            {
                return $@"
IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE name IS NOT NULL)
BEGIN
    {Regex.Replace(block, @"sp_addextendedproperty", "sys.sp_updateextendedproperty", RegexOptions.IgnoreCase)}
END
ELSE
BEGIN
    {Regex.Replace(block, @"sp_updateextendedproperty", "sys.sp_addextendedproperty", RegexOptions.IgnoreCase)}
END".Trim();
            }

            string esc(string s) => (s ?? string.Empty).Replace("'", "''");

            var sb = new StringBuilder();
            sb.AppendLine("DECLARE @__v sql_variant = N'" + esc(value) + "';");

            if (!string.IsNullOrEmpty(table) && string.IsNullOrEmpty(column))
            {
                sb.AppendLine($@"
IF EXISTS (SELECT 1 FROM sys.extended_properties 
           WHERE name = N'{esc(name)}' 
             AND major_id = OBJECT_ID(N'[{schema}].[{table}]')
             AND minor_id = 0)
BEGIN
    EXEC sys.sp_updateextendedproperty @name=N'{esc(name)}', @value=@__v,
        @level0type=N'SCHEMA', @level0name=N'{esc(schema)}',
        @level1type=N'TABLE',  @level1name=N'{esc(table)}';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty @name=N'{esc(name)}', @value=@__v,
        @level0type=N'SCHEMA', @level0name=N'{esc(schema)}',
        @level1type=N'TABLE',  @level1name=N'{esc(table)}';
END".Trim());
            }
            else if (!string.IsNullOrEmpty(table) && !string.IsNullOrEmpty(column))
            {
                sb.AppendLine($@"
IF EXISTS (SELECT 1 FROM sys.extended_properties 
           WHERE name = N'{esc(name)}' 
             AND major_id = OBJECT_ID(N'[{schema}].[{table}]')
             AND minor_id = COLUMNPROPERTY(OBJECT_ID(N'[{schema}].[{table}]'), N'{esc(column)}', 'ColumnId'))
BEGIN
    EXEC sys.sp_updateextendedproperty @name=N'{esc(name)}', @value=@__v,
        @level0type=N'SCHEMA', @level0name=N'{esc(schema)}',
        @level1type=N'TABLE',  @level1name=N'{esc(table)}',
        @level2type=N'COLUMN', @level2name=N'{esc(column)}';
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty @name=N'{esc(name)}', @value=@__v,
        @level0type=N'SCHEMA', @level0name=N'{esc(schema)}',
        @level1type=N'TABLE',  @level1name=N'{esc(table)}',
        @level2type=N'COLUMN', @level2name=N'{esc(column)}';
END".Trim());
            }
            else
            {
                sb.AppendLine($@"
IF EXISTS (SELECT 1 FROM sys.extended_properties WHERE name = N'{esc(name)}')
BEGIN
    EXEC sys.sp_updateextendedproperty @name=N'{esc(name)}', @value=@__v;
END
ELSE
BEGIN
    EXEC sys.sp_addextendedproperty @name=N'{esc(name)}', @value=@__v;
END".Trim());
            }

            return sb.ToString().Trim();
        }

        private static bool HasExplicitNullValue(string args)
        {
            return Regex.IsMatch(args, @"@value\s*=\s*NULL", RegexOptions.IgnoreCase);
        }
    }
}
