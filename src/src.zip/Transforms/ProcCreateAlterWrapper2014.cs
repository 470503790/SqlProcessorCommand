using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    /// <summary>
    /// 将 CREATE PROC/PROCEDURE 包装成：若存在则 ALTER，否则 CREATE（兼容 SQL Server 2014）。
    /// </summary>
    internal class ProcCreateAlterWrapper2014 : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+(?:PROC|PROCEDURE)\s+(?:(?:\[(?<schema>[^\]]+)\]\.\[(?<name>[^\]]+)\])|(?:(?<schema2>\w+)\.(?<name2>\w+))|(?:\[(?<name3>[^\]]+)\])|(?<name4>\w+))(?<rest>[\s\S]*)$",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            var m = R.Match(block);
            string schema = m.Groups["schema"].Success ? m.Groups["schema"].Value :
                            (m.Groups["schema2"].Success ? m.Groups["schema2"].Value : "dbo");
            string name = m.Groups["name"].Success ? m.Groups["name"].Value :
                          (m.Groups["name2"].Success ? m.Groups["name2"].Value :
                          (m.Groups["name3"].Success ? m.Groups["name3"].Value : m.Groups["name4"].Value));
            string rest = m.Groups["rest"].Value;

            string header = $"[{schema}].[{name}]";

            string alter = $"ALTER PROCEDURE {header}{rest}";
            string create = $"CREATE PROCEDURE {header}{rest}";

            return $@"
IF OBJECT_ID(N'{header}', N'P') IS NULL
BEGIN
    {create}
END
ELSE
BEGIN
    {alter}
END".Trim();
        }
    }
}
