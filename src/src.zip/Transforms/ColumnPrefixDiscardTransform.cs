using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class ColumnPrefixDiscardTransform : ISqlBlockTransform
    {
        private static readonly Regex AddColRx =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+ADD\s+(?<cols>.+)$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        private static readonly Regex DropColRx =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+DROP\s+COLUMN\s+(?<cols>.+)$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        private static readonly Regex AlterColRx =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+ALTER\s+COLUMN\s+(?<cols>.+)$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        private static readonly Regex BracketedIdRx = new Regex(@"\[(?<id>[^\]]+)\]", RegexOptions.IgnoreCase);

        private readonly string[] _prefixes;
        public ColumnPrefixDiscardTransform(params string[] prefixes)
        {
            _prefixes = (prefixes == null || prefixes.Length == 0) ? new[] { "ex_field_", "tmp_" } : prefixes;
        }

        public bool CanHandle(string block) => ShouldDiscard(block);
        public string Transform(string block) => string.Empty;

        private bool ShouldDiscard(string block)
        {
            Match m = AddColRx.Match(block);
            if (!m.Success) m = DropColRx.Match(block);
            if (!m.Success) m = AlterColRx.Match(block);
            if (!m.Success) return false;

            string colsPart = m.Groups["cols"]?.Value ?? string.Empty;
            var ids = BracketedIdRx.Matches(colsPart).Cast<Match>().Select(x => x.Groups["id"].Value);
            foreach (var id in ids)
                if (_prefixes.Any(p => id.StartsWith(p, System.StringComparison.OrdinalIgnoreCase))) return true;
            return false;
        }
    }
}
