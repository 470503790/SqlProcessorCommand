using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class CreateIndexTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+(?<type>(?:UNIQUE\s+)?(?:NONCLUSTERED|CLUSTERED)\s+)?INDEX\s+\[(?<ix>[^\]]+)\]\s+ON\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s*\(",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block)
        {
            var m = R.Match(block);
            var ix = m.Groups["ix"].Value;
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            return $@"
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'{SqlId.Unquote(ix)}' AND object_id = OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}'))
BEGIN
    {block}
END".Trim();
        }
    }
}
