namespace SqlProcessorCommand
{
    internal class GenericRegexWrapTransform : ISqlBlockTransform
    {
        public bool CanHandle(string block) => false;
        public string Transform(string block) => block;
    }
}
