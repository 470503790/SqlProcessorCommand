using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    /// <summary>
    /// 智能添加默认约束：如果目标列已存在默认约束则跳过；
    /// 若列无默认且欲添加的约束名在库内已占用，则使用“无名”默认（让 SQL Server 自动命名）。
    /// </summary>
    internal class AddDefaultConstraintTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*ALTER\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s+ADD\s+CONSTRAINT\s+\[(?<cname>[^\]]+)\]\s+DEFAULT\s+(?<def>\(.+?\))\s+FOR\s+\[(?<col>[^\]]+)\]\s*;?\s*$",
                      RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table  = m.Groups["table"].Value;
            var cname  = m.Groups["cname"].Value;
            var defExp = m.Groups["def"].Value.Trim();
            var col    = m.Groups["col"].Value;

            return $@"
IF NOT EXISTS (
    SELECT 1
    FROM sys.default_constraints dc
    JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[{schema}].[{table}]')
      AND c.name = N'{col}'
)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE name = N'{cname}' AND type = 'D')
    BEGIN
        ALTER TABLE [{schema}].[{table}] ADD CONSTRAINT [{cname}] DEFAULT {defExp} FOR [{col}];
    END
    ELSE
    BEGIN
        -- 约束名在库内已被占用（可能在其他表），使用无名默认，让系统生成 DF__... 名称
        ALTER TABLE [{schema}].[{table}] ADD DEFAULT {defExp} FOR [{col}];
    END
END".Trim();
        }
    }
}
