using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class CreateOrAlterTriggerTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+TRIGGER\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            return R.Replace(block, "CREATE OR ALTER TRIGGER");
        }
    }
}
