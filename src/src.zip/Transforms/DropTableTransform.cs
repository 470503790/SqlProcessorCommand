using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    internal class DropTableTransform : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*DROP\s+TABLE\s+(?:\[(?<schema>[^\]]+)\]\.)?\[(?<table>[^\]]+)\]\s*;?\s*$",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        public bool CanHandle(string block) => R.IsMatch(block);
        public string Transform(string block)
        {
            var m = R.Match(block);
            var schema = m.Groups["schema"].Success ? m.Groups["schema"].Value : "dbo";
            var table = m.Groups["table"].Value;
            return $@"
IF OBJECT_ID(N'{SqlId.Quote(schema)}.{SqlId.Quote(table)}', N'U') IS NOT NULL
BEGIN
    DROP TABLE {SqlId.Quote(schema)}.{SqlId.Quote(table)}
END".Trim();
        }
    }
}
