using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    /// <summary>
    /// 将 CREATE TRIGGER 包装为存在则 ALTER，否则 CREATE（兼容 SQL Server 2014）。
    /// </summary>
    internal class TriggerCreateAlterWrapper2014 : ISqlBlockTransform
    {
        private static readonly Regex R =
            new Regex(@"^\s*CREATE\s+TRIGGER\s+(?:(?:\[(?<schema>[^\]]+)\]\.\[(?<name>[^\]]+)\])|(?:(?<schema2>\w+)\.(?<name2>\w+))|(?:\[(?<name3>[^\]]+)\])|(?<name4>\w+))(?<rest>[\s\S]*)$",
                      RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        public bool CanHandle(string block) => R.IsMatch(block);

        public string Transform(string block)
        {
            var m = R.Match(block);
            string schema = m.Groups["schema"].Success ? m.Groups["schema"].Value :
                            (m.Groups["schema2"].Success ? m.Groups["schema2"].Value : "dbo");
            string name = m.Groups["name"].Success ? m.Groups["name"].Value :
                          (m.Groups["name2"].Success ? m.Groups["name2"].Value :
                          (m.Groups["name3"].Success ? m.Groups["name3"].Value : m.Groups["name4"].Value));
            string rest = m.Groups["rest"].Value;

            string header = $"[{schema}].[{name}]";

            string alter = $"ALTER TRIGGER {header}{rest}";
            string create = $"CREATE TRIGGER {header}{rest}";

            return $@"
IF OBJECT_ID(N'{header}', N'TR') IS NULL
BEGIN
    {create}
END
ELSE
BEGIN
    {alter}
END".Trim();
        }
    }
}
