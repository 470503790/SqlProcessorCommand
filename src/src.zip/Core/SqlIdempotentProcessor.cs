using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace SqlProcessorCommand
{
    public class SqlIdempotentProcessor
    {
        public class Options
        {
            public bool DiscardDropColumn { get; set; } = true;
        }

        private readonly List<ISqlBlockTransform> _pipeline;

        public SqlIdempotentProcessor(Options options = null, Action<PipelineBuilder> configure = null)
        {
            options ??= new Options();
            var builder = new PipelineBuilder();

            builder
                .Add(new ProcCreateAlterWrapper2014())
                .Add(new ViewCreateAlterWrapper2014())
                .Add(new TriggerCreateAlterWrapper2014())
                .Add(new FunctionCreateAlterWrapper2014());

            builder.Add(new CreateTableTransform());
            builder.Add(new AddDefaultConstraintTransform());

            if (options.DiscardDropColumn)
                builder.Add(new DropColumnToEmptyTransform());

            builder.Add(new GenericRegexWrapTransform());

            configure?.Invoke(builder);
            _pipeline = builder.Build();
        }

        public string Process(string sqlText)
        {
            if (string.IsNullOrWhiteSpace(sqlText)) return string.Empty;

            var blocks = Regex.Split(sqlText, @"^\s*GO\s*;?\s*$",
                RegexOptions.Multiline | RegexOptions.IgnoreCase);

            var sb = new StringBuilder();
            foreach (var raw in blocks)
            {
                var sql = raw?.Trim();
                if (string.IsNullOrEmpty(sql)) continue;

                string transformed = TransformOne(sql);
                if (!string.IsNullOrWhiteSpace(transformed))
                {
                    sb.AppendLine(transformed.TrimEnd());
                    sb.AppendLine("GO");
                    sb.AppendLine();
                }
            }
            return sb.ToString().Trim();
        }

        private string TransformOne(string sql)
        {
            foreach (var t in _pipeline)
            {
                if (t.CanHandle(sql)) return t.Transform(sql);
            }
            return sql;
        }
    }
}
