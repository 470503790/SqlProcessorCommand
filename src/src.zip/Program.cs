using System;
using System.IO;
using System.Text;

namespace SqlProcessorCommand
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            try
            {
                if (args.Length == 0 || HasFlag(args, "-h") || HasFlag(args, "--help"))
                {
                    PrintHelp();
                    return 0;
                }

                string input = GetOption(args, "--input") ?? GetOption(args, "-i");
                string output = GetOption(args, "--output") ?? GetOption(args, "-o");
                string tag = GetOption(args, "--name") ?? GetOption(args, "-n");
                string encName = GetOption(args, "--encoding");

                bool? discardDropColumn = null; // null=默认(true); true=丢弃; false=保留
                if (HasFlag(args, "--discard-drop-column")) discardDropColumn = true;
                if (HasFlag(args, "--keep-drop-column"))    discardDropColumn = false;

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.Error.WriteLine("ERROR: 必须指定输入文件，使用 -i <path> 或 --input <path>。");
                    PrintHelp();
                    return 2;
                }
                if (!File.Exists(input))
                {
                    Console.Error.WriteLine($"ERROR: 输入文件不存在: {input}");
                    return 3;
                }

                Encoding enc = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);
                if (!string.IsNullOrWhiteSpace(encName))
                {
                    try { enc = Encoding.GetEncoding(encName); }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"WARN: 不支持的编码 \"{encName}\": {ex.Message}，已回退为 UTF-8。");
                        enc = new UTF8Encoding(false);
                    }
                }

                var options = new SqlIdempotentProcessor.Options();
                if (discardDropColumn.HasValue) options.DiscardDropColumn = discardDropColumn.Value;

                string sql = File.ReadAllText(input, enc);
                var processor = new SqlIdempotentProcessor(options);
                string result = processor.Process(sql);

                if (string.IsNullOrWhiteSpace(output))
                {
                    string dir = Path.GetDirectoryName(Path.GetFullPath(input)) ?? Environment.CurrentDirectory;
                    string stem = Path.GetFileNameWithoutExtension(input);
                    string suffix = string.IsNullOrWhiteSpace(tag) ? "idempotent" : tag.Trim();
                    output = Path.Combine(dir, $@"{stem}.{suffix}.sql");
                }

                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output)) ?? ".");
                File.WriteAllText(output, result, enc);

                Console.WriteLine($"OK  输入: {input}");
                Console.WriteLine($"    输出: {output}");
                Console.WriteLine($"    编码: {enc.WebName}");
                Console.WriteLine($"    丢弃 DROP COLUMN: {(options.DiscardDropColumn ? "启用(默认)" : "关闭")}");
                if (!string.IsNullOrWhiteSpace(tag)) Console.WriteLine($"    名称: {tag}");
                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("FATAL: " + ex.Message);
                Console.Error.WriteLine(ex.ToString());
                return 1;
            }
        }

        private static bool HasFlag(string[] args, string flag)
        {
            foreach (var a in args) if (string.Equals(a, flag, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private static string GetOption(string[] args, string key)
        {
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (string.Equals(args[i], key, StringComparison.OrdinalIgnoreCase))
                    return args[i + 1];
            }
            return null;
        }

        private static void PrintHelp()
        {
            Console.WriteLine("SqlProcessorCommand - 将 SQL 文本处理为幂等化脚本");
            Console.WriteLine();
            Console.WriteLine("用法:");
            Console.WriteLine("  SqlProcessorCommand --input <input.sql> [--output <out.sql>] [--name <tag>] [--encoding <enc>]");
            Console.WriteLine("                       [--discard-drop-column | --keep-drop-column]");
            Console.WriteLine();
            Console.WriteLine("参数:");
            Console.WriteLine("  -i, --input            输入 SQL 文件路径（必填）");
            Console.WriteLine("  -o, --output           输出 SQL 文件路径（可选；默认: <输入名>.<name|idempotent>.sql）");
            Console.WriteLine("  -n, --name             命名（用于输出文件名后缀；可选）");
            Console.WriteLine("      --encoding         文本编码，默认 utf-8（示例：gb2312, gbk, utf-16）");
            Console.WriteLine("      --discard-drop-column  丢弃所有 ALTER TABLE ... DROP COLUMN 语句（默认开启）");
            Console.WriteLine("      --keep-drop-column     保留 DROP COLUMN 语句（覆盖默认）");
            Console.WriteLine("  -h, --help             显示帮助");
        }
    }
}
